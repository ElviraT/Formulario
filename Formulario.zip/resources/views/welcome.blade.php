@extends('layouts.Base')

@section('content')

<div class="col-12">
    <div class="row" align="center">
        <h1>{{'REGISTRO FINALIZADO'}}</h1>
    </div>
</div>
@endsection